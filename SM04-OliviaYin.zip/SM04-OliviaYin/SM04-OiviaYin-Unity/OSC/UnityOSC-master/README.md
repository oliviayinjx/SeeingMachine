# UnityOSC
Open Sound Control (OSC) for Unity 3D.

This Github is an actual Unity project. Open the folder in Unity.

The OSC script is named : OSC.cs
Its actual file can be found in "Assets\OSC"

Examples for Cycling '74 Max and TouchDesigner are included.

Documentation : http://thomasfredericks.github.io/UnityOSC/
